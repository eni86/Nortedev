from django.apps import AppConfig


class LotesConfig(AppConfig):
    name = 'lotes'
