from django.shortcuts import render
from django.views.generic import CreateView

class ListarLotes(CreateView):
    pass
# Create your views here.
