from django.apps import AppConfig


class AnimalConfig(AppConfig):
    name = 'animal'
