from django.apps import AppConfig


class MovimientosConfig(AppConfig):
    name = 'movimientos'
