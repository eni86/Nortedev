from django.shortcuts import render
from django.views.generic import CreateView
# Create your views here.
class ListarMovimientos(CreateView):
    pass
