"""mysite4 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url

from usuarios.views import SignUpView, BienvenidaView, SignInView, SignOutView, ListarUsuarios
from lotes.views import ListarLotes
from movimientos.views import ListarMovimientos
from animal.views import ListarAnimales
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', BienvenidaView.as_view(), name='bienvenida'),
    url(r'^registrate/$', SignUpView.as_view(), name='sign_up'),
    url(r'^incia-sesion/$', SignInView.as_view(), name='sign_in'),
    url(r'^cerrar-sesion/$', SignOutView.as_view(), name='sign_out'),
    url(r'^usuarios/$', ListarUsuarios.as_view(), name='lista_usuarios'),
    url(r'^lotes/$', ListarLotes.as_view(), name='lista_lotes'),
    url(r'^animales/$', ListarAnimales.as_view(), name='lista_animales'),
    url(r'^movimientos/$', ListarMovimientos.as_view(), name='lista_movimientos')

]
