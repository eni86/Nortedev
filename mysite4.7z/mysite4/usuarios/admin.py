from django.contrib import admin

# Register your models here.
from .models import Perfil_de_Usuario

@admin.register(Perfil_de_Usuario)
class PerfilAdmin(admin.ModelAdmin):
    list_display = ('idusuario', 'nombres', 'apellidos', 'clave', 'email')
